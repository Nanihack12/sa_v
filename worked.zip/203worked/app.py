from flask import Flask, render_template, request, redirect, url_for, make_response
from flask_pymongo import PyMongo
import csv

app = Flask(__name__)
app.config['MONGO_URI'] = 'mongodb://localhost:27017/try'  # Replace with your MongoDB URI
mongo = PyMongo(app)


@app.route('/', methods=['GET', 'POST'])
def index():
    if request.method == 'POST':
        name = request.form['name']
        rollno = request.form['rollno']
        section = request.form['section']
        backlogs = request.form['backlogs']

        # Store the data in the MongoDB collection
        mongo.db.students.insert_one({'name': name, 'rollno': rollno, 'section': section, 'backlogs': backlogs})

        return redirect(url_for('submitted'))
    return render_template('index.html')


@app.route('/submitted')
def submitted():
    return render_template('submitted.html')


@app.route('/display_data')
def display_data():
    # Retrieve the student data from the MongoDB collection
    students = mongo.db.students.find()
    return render_template('display_data.html', students=students)


@app.route('/download_excel')
def download_excel():
    # Retrieve the student data from the MongoDB collection
    students = mongo.db.students.find()

    # Create a CSV string
    csv_string = 'Name,Roll No,Section,Backlogs\n'
    for student in students:
        csv_string += '{},{},{},{}\n'.format(student['name'], student['rollno'], student['section'], student['backlogs'])

    # Create a response with the CSV content
    response = make_response(csv_string)
    response.headers['Content-Disposition'] = 'attachment; filename=student_data.csv'
    response.headers['Content-type'] = 'text/csv'

    return response


if __name__ == '__main__':
    app.run(debug=True)
